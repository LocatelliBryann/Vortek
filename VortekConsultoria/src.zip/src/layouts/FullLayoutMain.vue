<template>
  <v-app>

    <div>
      <!-- mantém o vídeo -->
      <VideoIntro
      v-if="mostrarVideo"
      @video-finalizado="videoFinalizado"
      />
      
      <!-- conteúdo da página -->
      <div v-else class="bg-page">
        <!-- HERO -->
        <section class="hero">
          <v-container class="py-12">
            <v-row align="center" justify="space-between" class="gap-y-6">
              <v-col cols="12" md="7">
                <h1 class="hero__title">Suporte de TI ágil e seguro.</h1>
                <p class="hero__subtitle">
                  Help desk humano, monitoramento 24×7, segurança, backups e nuvem.
                </p>
                
                <div class="hero__cta">
                  <RouterLink to="/contate">
                    <v-btn size="large" class="btn-primary" prepend-icon="mdi-email-fast">
                      Fale com a gente
                    </v-btn>
                  </RouterLink>
                  
                  <RouterLink to="/about">
                    <v-btn size="large" variant="text" class="btn-ghost" append-icon="mdi-arrow-right">
                      Sobre nós
                    </v-btn>
                  </RouterLink>
                </div>
              </v-col>
              
              <v-col cols="12" md="5" class="text-center">
                <v-card class="dashboard-card">
                  <v-card-text>
                    <v-icon size="56" class="mb-3">mdi-laptop</v-icon>
                    <h3 class="mb-1">Visão unificada</h3>
                    <p class="muted">
                      Tickets, ativos, backups e alertas em um painel simples.
                    </p>
                  </v-card-text>
                  <v-divider />
                  <v-card-actions class="justify-center">
                    <RouterLink to="/producoes">
                      <v-btn variant="text" class="link-white" append-icon="mdi-eye-arrow-right">
                        Ver demos
                      </v-btn>
                    </RouterLink>
                  </v-card-actions>
                </v-card>
              </v-col>
            </v-row>
          </v-container>
        </section>
        
        <!-- SERVIÇOS -->
        <section class="section section--dark">
          <v-container>
            <h2 class="section__title">O que fazemos</h2>
            
            <v-row>
              <v-col cols="12" md="4">
                <v-card class="service-card" variant="flat">
                  <v-card-title class="card-title">
                    <v-icon class="mr-2">mdi-headset</v-icon> Help Desk & Field
                  </v-card-title>
                  <v-card-text class="muted">
                    Atendimento remoto e presencial com base de conhecimento e playbooks.
                  </v-card-text>
                </v-card>
              </v-col>
              
              <v-col cols="12" md="4">
                <v-card class="service-card" variant="flat">
                  <v-card-title class="card-title">
                    <v-icon class="mr-2">mdi-shield-lock</v-icon> Segurança & LGPD
                  </v-card-title>
                  <v-card-text class="muted">
                    NGAV, MFA, backups, hardening e relatórios claros para a gestão.
                  </v-card-text>
                </v-card>
              </v-col>
              
              <v-col cols="12" md="4">
                <v-card class="service-card" variant="flat">
                  <v-card-title class="card-title">
                    <v-icon class="mr-2">mdi-cloud-sync</v-icon> Infra & Cloud
                  </v-card-title>
                  <v-card-text class="muted">
                    Redes, servidores e nuvem com automação e monitoramento 24×7.
                  </v-card-text>
                </v-card>
              </v-col>
            </v-row>
          </v-container>
        </section>
        
        <!-- COMO TRABALHAMOS (4 passos curtos) -->
        <section class="section">
          <v-container>
            <h2 class="section__title">Como trabalhamos</h2>
            <v-row>
              <v-col cols="12" md="3" v-for="(step, i) in passos" :key="i">
                <v-sheet class="step-card" rounded="xl" elevation="3">
                  <div class="step__num">{{ i + 1 }}</div>
                  <h3 class="card-title">{{ step.titulo }}</h3>
                  <p class="muted">{{ step.desc }}</p>
                </v-sheet>
              </v-col>
            </v-row>
          </v-container>
        </section>
      </div>
    </div>
  </v-app>
  </template>

<script>
import VideoIntro from "@/components/VideoIntro.vue";

export default {
  name: "MainView",
  components: { VideoIntro },
  data() {
    return {
      mostrarVideo: true,
      passos: [
        { titulo: "Diagnóstico", desc: "Levantamento do ambiente e prioridades." },
        { titulo: "Plano de Ação", desc: "Roadmap com quick wins e metas." },
        { titulo: "Execução", desc: "Sprints com comunicação clara." },
        { titulo: "Melhoria contínua", desc: "Métricas, relatórios e ajustes." }
      ]
    };
  },
  mounted() {
    if (sessionStorage.getItem("videoAssistido")) this.mostrarVideo = false;
  },
  methods: {
    videoFinalizado() {
      this.mostrarVideo = false;
      sessionStorage.setItem("videoAssistido", "true");
    }
  }
};
</script>

<style scoped>
/* ---- Cores base (claro sobre escuro) ---- */
:root {
  --bg-dark: #0a0a0a;
  --bg-darker: #050505;
  --text: #ffffff;
  --muted: rgba(255,255,255,.82);
  --accent: #ff7a1a;
  --accent-2: #ff9a3c;
}
.bg-page { background: linear-gradient(180deg, var(--bg-darker), #111); color: var(--text); }

/* Força tipografia clara para evitar “preto no preto” */
.bg-page, .bg-page *:where(h1,h2,h3,h4,h5,h6,p,span,small,li,blockquote) {
  color: var(--text);
}
.muted { color: var(--muted) !important; }

/* HERO */
.hero {
  background: radial-gradient(1200px 500px at 20% 0%, rgba(255,122,26,.14), transparent 50%),
  radial-gradient(800px 400px at 100% 10%, rgba(255,154,60,.10), transparent 60%);
}
.hero__title { font-size: clamp(28px, 4vw, 48px); line-height: 1.1; font-weight: 800; }
.hero__subtitle { margin-top: 12px; font-size: 1.1rem; max-width: 58ch; color: var(--muted); }
.hero__cta { margin-top: 22px; display: flex; gap: 12px; flex-wrap: wrap; }

.dashboard-card {
  background: #141414; border: 1px solid rgba(255,255,255,.08);
}

/* SEÇÕES */
.section { padding: 60px 0; }
.section--dark { background: #0e0e0e; }
.section__title { font-size: clamp(22px, 3vw, 34px); font-weight: 800; margin-bottom: 18px; }

/* CARDS/steps */
.card-title { font-weight: 700; }
.service-card {
  background: linear-gradient(180deg, #121212, #0c0c0c);
  border: 1px solid rgba(255,255,255,.06);
}
.step-card { background: #141414; border: 1px solid rgba(255,255,255,.06); padding: 20px; }
.step__num { width: 38px; height: 38px; border-radius: 999px; display: grid; place-content: center; background: rgba(255,122,26,.18); color: var(--accent); font-weight: 800; margin-bottom: 8px; }

/* Botões/links */
.btn-primary {
  background: linear-gradient(90deg, var(--accent), var(--accent-2));
  color: #111 !important; font-weight: 800;
}
.btn-ghost { color: var(--text) !important; opacity: .9; }
.link-white { color: var(--text) !important; }
</style>
